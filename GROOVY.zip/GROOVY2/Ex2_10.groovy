Map m=[‘Computing’ : [‘Computing’ : 600, ‘InformationSystems’ : 300],
       ‘Engineering’ : [‘Civil’ : 200, ‘Mechanical’ : 100],
       ‘Management’ : [‘Management’ : 800]
       ]
println m.keySet()
println m['Computing']
//println m.get['Engineering'].get['Civil']