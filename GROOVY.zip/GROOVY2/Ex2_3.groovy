(1..10).each{
println "2*${it} =${2*it}";
}
print "\n"
(1..10).each{
println "12*${it} =${12*it}";
}