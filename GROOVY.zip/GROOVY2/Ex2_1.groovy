List l=[1,1,1,2,2,3,4,5,6]
println l
Set s= l as Set  //FIRST WAY
println s
l.unique()    //SECOND WAY
println l