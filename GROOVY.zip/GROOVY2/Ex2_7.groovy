Map m1=[1:"aroop",2:"sonu"]
Map m2=[3:"harish",4:"chandra"]
Map m3=m1+m2
print m3