Map m = ['1' : 2, '2' : 3, '3' : 4, '2':5] //VALID
println m['2']
println m.containsKey('2');