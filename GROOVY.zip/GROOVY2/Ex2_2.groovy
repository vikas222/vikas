Range r=(1..10)
println r
println r.getFrom()
println r[1]
println r.getTo()