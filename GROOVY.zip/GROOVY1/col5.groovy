List l1=(1..10)
println l1
l1.findAll{
if(it%2!=0)

}
print l1;