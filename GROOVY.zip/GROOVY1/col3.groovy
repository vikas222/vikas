List l1=(11..14)
List l2=(13..15)
println l1
println l2
List l3=l1-l2
print l3
