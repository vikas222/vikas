List l=(1..10)
println l
println l.head()
println l.last()