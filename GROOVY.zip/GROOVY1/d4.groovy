if('test')
println "test evaluated to true inside if"
if("Test")
println "test evaluated to true inside if"
if('null')
println "test evaluated to true inside if"
if(null)
println "test evaluated to true inside if"
else
println "test evaluated to false inside if"
if(100)
println "test evaluated to true inside if"
if(0)
println "test evaluated to true inside if"
else
println "test evaluated to false inside if"
List l=[]
if(l)
println "test evaluated to true inside if"
else
println "test evaluated to false inside if"
List l2=new ArrayList();
if(l2)
println "test evaluated to true inside if"
else
println "test evaluated to false inside if"