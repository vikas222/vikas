def a;
4.times
{
   a=2**it;
   a.times{print( "*")};
   print "\n";
}