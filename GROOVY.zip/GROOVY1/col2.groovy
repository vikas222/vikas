List l=(1..20)
l.each
{
 ele->
 if(ele%5==0)
 print ele+"\t"
}
