10.times
{
   print(3*(it+1));
   print("\t");
}
print "\n"
1.upto(10,

  {print(3*it+"\t");}
)
print "\n"
1.step 11,1,{print(3*it+"\t");}
