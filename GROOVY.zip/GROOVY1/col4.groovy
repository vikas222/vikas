List l1=(11..14)
List l2=(13..15)
println l1
println l2
if(l1.disjoint(l2))
print "Lists are Disjoint"
else
print "List are not Disjoint"
